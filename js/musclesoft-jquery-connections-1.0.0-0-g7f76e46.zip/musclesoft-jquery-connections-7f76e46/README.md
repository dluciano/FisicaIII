jQuery Connections
==================
A jQuery plugin for adding stylable connecting lines between block elements.

## Documentation

Please see the [Wiki](https://github.com/musclesoft/jquery-connections/wiki) for instructions and examples.

## Contributing

You're welcome to add to the [Wiki](https://github.com/musclesoft/jquery-connections/wiki),
fork and send pull requests.

## License

Released under the [MIT license terms](LICENSE.txt).
